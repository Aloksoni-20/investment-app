import { motion, useInView } from "framer-motion";
import { useRef, useState } from "react";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};

const stagger = {
  visible: { transition: { staggerChildren: 0.08 } },
};

const RegistrationForm = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    organisation: "",
    role: "",
    city: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const inputClass =
    "w-full bg-secondary/50 border border-border rounded-sm px-4 py-3 text-foreground font-body text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors";
  const selectClass =
    "w-full bg-secondary/50 border border-border rounded-sm px-4 py-3 text-foreground font-body text-sm focus:outline-none focus:border-primary transition-colors appearance-none";

  if (submitted) {
    return (
      <section id="register" className="section-padding bg-card-gradient">
        <div className="max-w-lg mx-auto text-center">
          <div className="gold-border rounded-sm p-12 gold-glow">
            <p className="text-primary font-heading text-3xl font-bold mb-4">Thank You!</p>
            <p className="text-muted-foreground font-body text-sm">
              Your registration has been received. We'll be in touch soon with further details.
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <motion.section
      id="register"
      ref={ref}
      initial="hidden"
      animate={inView ? "visible" : "hidden"}
      variants={stagger}
      className="section-padding bg-card-gradient"
    >
      <div className="max-w-lg mx-auto">
        <motion.div variants={fadeUp} className="text-center mb-12">
          <p className="text-primary font-body text-xs uppercase tracking-[0.3em] mb-3">Register</p>
          <h2 className="font-heading text-3xl md:text-5xl font-bold">Secure Your Spot</h2>
          <div className="w-16 h-px bg-primary mx-auto mt-6" />
        </motion.div>

        <motion.form variants={stagger} onSubmit={handleSubmit} className="space-y-5">
          <motion.div variants={fadeUp}>
            <input
              name="fullName"
              value={form.fullName}
              onChange={handleChange}
              placeholder="Full Name"
              required
              maxLength={100}
              className={inputClass}
            />
          </motion.div>
          <motion.div variants={fadeUp}>
            <input
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              placeholder="Email Address"
              required
              maxLength={255}
              className={inputClass}
            />
          </motion.div>
          <motion.div variants={fadeUp}>
            <input
              name="organisation"
              value={form.organisation}
              onChange={handleChange}
              placeholder="Organisation / Startup Name"
              maxLength={100}
              className={inputClass}
            />
          </motion.div>
          <motion.div variants={fadeUp}>
            <select name="role" value={form.role} onChange={handleChange} required className={selectClass}>
              <option value="" disabled>Select Your Role</option>
              <option value="Startup">Startup Founder</option>
              <option value="Investor">Investor</option>
              <option value="Sponsor">Sponsor</option>
              <option value="Partner">Partner</option>
            </select>
          </motion.div>
          <motion.div variants={fadeUp}>
            <select name="city" value={form.city} onChange={handleChange} required className={selectClass}>
              <option value="" disabled>City of Attendance</option>
              <option value="Johannesburg">Johannesburg – 14 April 2026</option>
              <option value="Cape Town">Cape Town – 21 April 2026</option>
            </select>
          </motion.div>
          <motion.div variants={fadeUp} className="pt-2">
            <button
              type="submit"
              className="w-full bg-gold-gradient text-primary-foreground font-body font-semibold px-8 py-4 rounded-sm text-sm uppercase tracking-widest hover:opacity-90 transition-opacity"
            >
              Register Now
            </button>
          </motion.div>
        </motion.form>
      </div>
    </motion.section>
  );
};

export default RegistrationForm;
