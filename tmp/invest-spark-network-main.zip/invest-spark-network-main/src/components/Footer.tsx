import { Mail, Phone } from "lucide-react";

const Footer = () => (
  <footer className="border-t border-border">
    {/* Contact */}
    <div className="section-padding max-w-4xl mx-auto text-center" id="contact">
      <p className="text-primary font-body text-xs uppercase tracking-[0.3em] mb-3">Get In Touch</p>
      <h2 className="font-heading text-3xl md:text-4xl font-bold mb-8">Contact Us</h2>
      <div className="flex flex-col sm:flex-row justify-center gap-8 text-muted-foreground font-body text-sm">
        <a href="mailto:info@investconnect.co.za" className="flex items-center gap-2 hover:text-primary transition-colors">
          <Mail className="w-4 h-4" /> info@investconnect.co.za
        </a>
        <span className="flex items-center gap-2">
          <Phone className="w-4 h-4" /> +27 XXX XXX XXX
        </span>
      </div>
    </div>

    {/* Bottom bar */}
    <div className="border-t border-border px-6 py-8 text-center">
      <p className="font-heading text-lg font-bold mb-1">
        Invest<span className="text-gradient-gold">Connect</span>
        <span className="text-muted-foreground font-body text-sm font-normal ml-2 italic">Pitch & Partner</span>
      </p>
      <p className="text-muted-foreground font-body text-xs mt-2">
        Connecting ideas, capital, and partnerships.
      </p>
      <p className="text-muted-foreground/50 font-body text-xs mt-4">
        © 2026 InvestConnect. All rights reserved.
      </p>
    </div>
  </footer>
);

export default Footer;
